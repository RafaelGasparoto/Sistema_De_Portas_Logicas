/****************************************************************************
** Meta object code from reading C++ file 'janelaprincipal.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../SistemaDePortasLogicas/janelaprincipal.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'janelaprincipal.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_janelaPrincipal_t {
    const uint offsetsAndSize[24];
    char stringdata0[159];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(offsetof(qt_meta_stringdata_janelaPrincipal_t, stringdata0) + ofs), len 
static const qt_meta_stringdata_janelaPrincipal_t qt_meta_stringdata_janelaPrincipal = {
    {
QT_MOC_LITERAL(0, 15), // "janelaPrincipal"
QT_MOC_LITERAL(16, 13), // "selecionaNovo"
QT_MOC_LITERAL(30, 0), // ""
QT_MOC_LITERAL(31, 14), // "selecionaAbrir"
QT_MOC_LITERAL(46, 15), // "selecionaSalvar"
QT_MOC_LITERAL(62, 13), // "selecionaSair"
QT_MOC_LITERAL(76, 16), // "selecionaVerdade"
QT_MOC_LITERAL(93, 14), // "selecionaFalso"
QT_MOC_LITERAL(108, 12), // "selecionaAND"
QT_MOC_LITERAL(121, 11), // "selecionaOR"
QT_MOC_LITERAL(133, 12), // "selecionaNOT"
QT_MOC_LITERAL(146, 12) // "selecionaLED"

    },
    "janelaPrincipal\0selecionaNovo\0\0"
    "selecionaAbrir\0selecionaSalvar\0"
    "selecionaSair\0selecionaVerdade\0"
    "selecionaFalso\0selecionaAND\0selecionaOR\0"
    "selecionaNOT\0selecionaLED"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_janelaPrincipal[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
       1,    0,   74,    2, 0x08,    1 /* Private */,
       3,    0,   75,    2, 0x08,    2 /* Private */,
       4,    0,   76,    2, 0x08,    3 /* Private */,
       5,    0,   77,    2, 0x08,    4 /* Private */,
       6,    0,   78,    2, 0x08,    5 /* Private */,
       7,    0,   79,    2, 0x08,    6 /* Private */,
       8,    0,   80,    2, 0x08,    7 /* Private */,
       9,    0,   81,    2, 0x08,    8 /* Private */,
      10,    0,   82,    2, 0x08,    9 /* Private */,
      11,    0,   83,    2, 0x08,   10 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void janelaPrincipal::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<janelaPrincipal *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->selecionaNovo(); break;
        case 1: _t->selecionaAbrir(); break;
        case 2: _t->selecionaSalvar(); break;
        case 3: _t->selecionaSair(); break;
        case 4: _t->selecionaVerdade(); break;
        case 5: _t->selecionaFalso(); break;
        case 6: _t->selecionaAND(); break;
        case 7: _t->selecionaOR(); break;
        case 8: _t->selecionaNOT(); break;
        case 9: _t->selecionaLED(); break;
        default: ;
        }
    }
    (void)_a;
}

const QMetaObject janelaPrincipal::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_janelaPrincipal.offsetsAndSize,
    qt_meta_data_janelaPrincipal,
    qt_static_metacall,
    nullptr,
qt_incomplete_metaTypeArray<qt_meta_stringdata_janelaPrincipal_t
, QtPrivate::TypeAndForceComplete<janelaPrincipal, std::true_type>
, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>, QtPrivate::TypeAndForceComplete<void, std::false_type>


>,
    nullptr
} };


const QMetaObject *janelaPrincipal::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *janelaPrincipal::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_janelaPrincipal.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int janelaPrincipal::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
